# This is the main file for MyPong.

from tkinter import *
import table, ball, bat

# initialise global variables
x_velocity = 10
y_velocity = 10

# order a window from the tkinter window factory
window = Tk()
window.title("My Keepy Uppy Game")
       
# order a table from the table class without a net
my_table = table.Table(window)

# order a ball from the ball factory
my_ball = ball.Ball(table=my_table, x_speed=x_velocity, y_speed=y_velocity,
                    width=24, height=24, colour="red", x_start=288, y_start=188)

# order a left and right bat from the bat class
my_bat = bat.Bat(table=my_table, width=100, height=15, x_posn=250, y_posn=350, colour="blue")


#### functions:
def game_flow():
    # detect if ball has hit the bats:
    my_bat.detect_collision(my_ball)
    
    my_ball.move_next()
    window.after(50, game_flow)

# bind the controls of the bats to keys on the keyboard
window.bind("<Left>", my_bat.move_left)
window.bind("<Right>", my_bat.move_right)

# call the game_flow loop
game_flow()

# start the tkinter loop process
window.mainloop()
