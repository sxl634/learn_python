# pet_owner.py
# There are many ways of doing this challenge. This is just one.

import pet

# create two pets
romeo = pet.Pet("Tarantula")
juliet = pet.Pet("Piranha")

# play with your spider
romeo.eat()
romeo.sleep()

# play with your fish
juliet.eat()
juliet.sleep()
