# pet.py provides an improved Cat Class

class Pet:
    # constructor
    def __init__(self, name):
        self.name = name

    # other methods
    def sleep(self):
        print(self.name, "goes to sleep.")

    def eat(self):
        print(self.name, "eats some food.")
        print(self.name, "wants some more food.")
