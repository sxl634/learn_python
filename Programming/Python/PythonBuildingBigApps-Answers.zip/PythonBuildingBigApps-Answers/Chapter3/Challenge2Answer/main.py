# This is the main file for MyPong.

from tkinter import *
import table

# order a window from the tkinter window factory
window = Tk()
window.title("MyPong")
       
# order a table from the table class
my_table = table.Table(window, width=500, height=500, colour="blue", net_colour="black", vertical_net=True)

# start the animation loop
window.mainloop()
