# Ch1-Idea2.py is a quick revision application.

import random

# Initialise variables:
response1 = "I am afraid not. Please try again."
response2 = "That is a good password but not my password. Keep guessing."
response3 = "That is not my password. It really is easy to guess my password."
response4 = "Well done! You must work for MI6. Give my regards to James Bond."
MY_PASSWORD = "my password"

# Three new variables:
guess_correct = False
counter = 0
gave_in = False

def is_correct(guess, password):
    return guess == password

# Start the game:
print("Hello.\n")
users_guess = input("See if you can guess my password? ")

# Use our function:
true_or_false = is_correct(users_guess, MY_PASSWORD)

# Run the game until the user is correct:
while true_or_false == False:
    computer_response = random.randint(1, 3)

    # Check for the third attempt:
    if counter >= 2:
        yes_or_no = input("Do you give in? Y/N? ")
        if (yes_or_no == "Y" or yes_or_no == "y"):
            print("My password was \"my password\". Get it?")
            gave_in = True
            break
        else:
            print("\nOK lets continue ...")

    if computer_response == 1:
        print(response1)
    elif computer_response == 2:
        print(response2)
    else:
        print(response3)

    # Collect the user's next guess:
    users_guess = input("\nWhat is your next guess? ")

    # Use our function again:
    true_or_false = is_correct(users_guess, MY_PASSWORD)

    # add one to the counter:
    counter = counter+1

# End the game:
if gave_in == False: print(response4) # This is also a new line
input("\n\n\nPress RETURN to exit.")
