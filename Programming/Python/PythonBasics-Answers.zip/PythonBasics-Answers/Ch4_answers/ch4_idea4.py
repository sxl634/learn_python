# ch4_idea4.py
# This game uses a home made function, adds in a counter and has a choice of levels.

import random

# create variables:
counter = 1

# Create the function is_same()
def is_same(target, number):
    if target == number:
        result="Win"
    elif target > number:
        result="Low"
    else:
        result="High"

    return result

# Ask for users level choice:
level = input("Hello.\nPlease choose which game to play: Easy, Medium or Hard?\ne/m/h:")

while level != "e" and level != "m" and level != "h":
    level = input("Sorry. You must type in one of the letters 'e', 'm' or 'h'\ne/m/h:")

# select level
if level == "e":
    upper_limit = 10
elif level == "m":
    upper_limit = 20
else:
    upper_limit = 100
    
# Think of a number
computer_number = random.randint(1, upper_limit)

# Start the game
print("\nI have thought of a number between 1 and ", upper_limit)

# Collect the user's guess as an integer
guess = int(input("Can you guess it? "))

# Use our function
higher_or_lower = is_same(computer_number, guess)

# Run the game until the user is correct
while higher_or_lower != "Win":

    if higher_or_lower == "Low":
        guess = int(input("Sorry, you are too low. Try again. "))
        counter = counter+1
    else:
        guess = int(input("Sorry, you are too high. Try again. "))
        counter = counter+1

    higher_or_lower = is_same(computer_number, guess)


print("Correct!\nWell Done and it only took you", counter, "guesses.")

# End the game
input("\n\n\nPress RETURN to exit.")
