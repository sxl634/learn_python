# ch4_idea1.py
# This game uses a home made function

# Start app and collect choices
which_table = int(input("Hello.\nWhich times table would you like. Type a number:\n"))
how_many_rows = int(input("How many rows do you want? Type a number:\n"))

def times_tables(how_far, num):
    n=1
    while n<= how_far:
        print(n, " x ", num, " = ", n*num)
        n = n+1

# Add a line return
print()

# Use our function
times_tables(how_many_rows, which_table)

# End the game# adds a line return
input("\n\nPress RETURN to exit.")
