#### Chapter 2 Answers

# Puzzle 1
number=1
while number<11:
    print(number*2)
    number=number+1


# Puzzle 2
number=1
while number<11:
    print(number, "x 5 =", number*5)
    number=number+1


# Puzzle 3v1
number=1
while number<=100:
    print(number)
    number=number+1


# Puzzle 3v2
number=1
while 101>number:
    print(number)
    number=number+1


# Puzzle 3v3
number=1
while number!=101:
    print(number)
    number=number+1
